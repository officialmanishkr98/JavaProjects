package com.thirdMysql;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ThirdMysqlApplication {

	public static void main(String[] args) {
		SpringApplication.run(ThirdMysqlApplication.class, args);
	}

}
