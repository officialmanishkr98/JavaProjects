package com.example.iocdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IocdemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
