package com.example.iocdemo.service;

import org.springframework.stereotype.Service;

@Service
public class TestService {
	
	 public String getHello() {
		return "Hello from test service";
		 
	 }

}
